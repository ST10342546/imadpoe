package com.simone.calcpoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var num1: EditText
    private lateinit var num2: EditText
    private lateinit var addBtn: Button
    private lateinit var subtractionBtn: Button
    private lateinit var multiplyBtn: Button
    private lateinit var divideBtn: Button
    private lateinit var powerBtn: Button
    private lateinit var sqrtBtn: Button
    private lateinit var DisplayAns: TextView
    private lateinit var statfunBtn:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        num1 = findViewById(R.id.num1)
        num2 = findViewById(R.id.num2)
        addBtn = findViewById(R.id.addBtn)
        subtractionBtn = findViewById(R.id.subtractionBtn)
        multiplyBtn = findViewById(R.id.multiplyBtn)
        divideBtn = findViewById(R.id.divideBtn)
        sqrtBtn = findViewById(R.id.sqrtBtn)
        powerBtn = findViewById(R.id.powerBtn)
        DisplayAns = findViewById(R.id.DisplayAns)


        addBtn.setOnClickListener {
            val num1 = num1.text.toString().toDouble()
            val num2 = num2.text.toString().toDouble()
            val total = num1 + num2
            DisplayAns.text= "" + num1 + "+" + num2 + "=" + total"
        }
        subtractionBtn.setOnClickListener {
            val num1 = num1.text.toString().toDouble()
            val num2 = num2.text.toString().toDouble()
            val total = num1 - num2
            DisplayAns.text= "" + num1 + "-" + num2 + "=" + total"
        }
        multiplyBtn.setOnClickListener {
            val num1 = num1.text.toString().toDouble()
            val num2 = num2.text.toString().toDouble()
            val total = num1 * num2
            DisplayAns.text= "" + num1 + "*" + num2 + "=" + total"
        }
        divideBtn.setOnClickListener {
            val num1 = num1.text.toString().toDouble()
            val num2 = num2.text.toString().toDouble()
            val total = num1 / num2
            DisplayAns.text= "" + num1 + "/" + num2 + "=" + total"
        }
        powerBtn.setOnClickListener {
            val num1 = num1.text.toString().toDouble()
            val num2 = num2.text.toString().toDouble()
            val total = Math.pow(num1, num2)
            DisplayAns.text= "" + num1 + "^" + num2 + "=" + total"
        }
        sqrtBtn.setOnClickListener{
            val num1 = num1.text.toString().toDouble()
            val total = Math.sqrt(num1)
            DisplayAns.text= "" + num1 + "sqrt($num1) =$total"
        }
        statfunBtn.setOnClickListener {
            val intent Intent(this, StatsFrags::class.java)
            startActivity(intent)
        }
    }

}



