package com.simone.calcpoe

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StatsFrags : AppCompatActivity() {
        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

                val minMaxbtn: Button = findViewById(R.id.minMaxbtn)
                val addButton: Button = findViewById(R.id.addButton)
                val clearBtn: Button = findViewById(R.id.clearBtn)
                val calcAvg: Button = findViewById(R.id.calcAvg)
                val memoryTxt: TextView = findViewById(R.id.memoryTxt)
                val answerTxt : TextView = findViewById(R.id.answerTxt)
                val NumberText : EditText = findViewById(R.id.NumberText)

                val history:mutableListOf = mutableListOf<Int>()

                addButton.setOnClickListener {
                        val number = NumberText.text.toString().ToIntOrNull()

                        if(number != null && history.size<9){
                                history.add(number)
                                memoryTxt.text = history.joinToString(",")
                        }
                        if (history.size ==10 ){
                                addButton.isEnabled = false
                        }
                        NumberText.text.clear()
                }
                clearBtn.setOnClickListener {
                        history.clear()
                        memoryTxt.text = ""
                        addButton.isEnabled = true

                }
                calcAvg.setOnClickListener {
                        val memoryTxt = memoryTxt.text.toString()
                        val StringNum = memoryTxt.split("")
                        val numbers = numberStrings.mapNotNull { it.toDoubleOrNull()}

                        if (numbers.isNotEmpty()) {
                                val average = numbers.average()
                                answerTxt.text= "Average: $average"
                        }
                }
                minMaxbtn.setOnClickListener {
                        val values = answerTxt.text.toString()
                        if(values.isBlank()){
                                answerTxt.text="No valid numbers"
                        }
                        val values = values.split(",").map {it.trim().toInt() }
                        val minimumValue = values.minOrNull()
                        val maximumValue = values.maxOrNull()

                        answerTxt.text= "Minimum Value: $minimumValue," + "Maximum Value: $maximumValue"


                }
}
}


